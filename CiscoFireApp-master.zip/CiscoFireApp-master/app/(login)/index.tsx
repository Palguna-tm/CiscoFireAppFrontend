import React, { useState, useRef } from 'react';
import { TextInput, Button, StyleSheet, Animated, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { Text, View, useThemeColor } from '@/components/Themed';
import { Ionicons } from '@expo/vector-icons';
import config from '../config'; // Import the config

export default function LoginScreen() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();

  const inputBorderColor = useThemeColor({}, 'tint'); // Changed 'border' to 'tint'
  const inputBackgroundColor = useThemeColor({}, 'background');
  const textColor = useThemeColor({}, 'text');

  const fadeAnim = useRef(new Animated.Value(0)).current;

  const handleLogin = async () => {
    if (!username || !password) {
      setError('Please enter both username and password');
      return;
    }

    try {
      const response = await fetch(`${config.apiUrl}/mobile/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      if (!response.ok) {
        throw new Error('Login failed');
      }

      const data = await response.json();
      // Handle successful login, e.g., save token, navigate, etc.
      setError('');
      router.push('/(tabs)');
    } catch (error) {
      setError('Login failed. Please try again.');
    }
  };

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  React.useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);

  return (
    <Animated.View style={[styles.container, { opacity: fadeAnim }]}>
      <Text style={styles.title}>Login</Text>
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <TextInput
        style={[styles.input, { borderColor: inputBorderColor, backgroundColor: inputBackgroundColor, color: textColor }]}
        placeholder="Username"
        placeholderTextColor={textColor}
        value={username}
        onChangeText={setUsername}
      />
      <View style={[styles.input, styles.passwordContainer, { borderColor: inputBorderColor, backgroundColor: inputBackgroundColor }]}>
        <TextInput
          style={[styles.passwordInput, { color: textColor }]}
          placeholder="Password"
          placeholderTextColor={textColor}
          secureTextEntry={!passwordVisible}
          value={password}
          onChangeText={setPassword}
        />
        <TouchableOpacity style={styles.eyeIcon} onPress={togglePasswordVisibility}>
          <Ionicons name={passwordVisible ? 'eye' : 'eye-off'} size={24} color={textColor} />
        </TouchableOpacity>
      </View>
      <Button title="Login" onPress={handleLogin} />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
  },
  title: {
    fontSize: 24,
    marginBottom: 16,
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    position: 'relative',
  },
  passwordInput: {
    flex: 1,
    paddingRight: 40, // Add padding to avoid text overlap with the icon
  },
  eyeIcon: {
    position: 'absolute',
    right: 10,
    height: '100%',
    justifyContent: 'center',
  },
  error: {
    color: 'red',
    marginBottom: 8,
    textAlign: 'center',
  },
});
