const config = {
  apiUrl: 'http://192.168.0.52:3000',
  // Add other configuration values or secrets here
  // For example, you might have:
  // apiKey: 'your-api-key',
  // authDomain: 'your-auth-domain',
};

export default config;

